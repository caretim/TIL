from django.apps import AppConfig


class PairPjt1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pair_pjt1'
