from django.shortcuts import render, redirect
from .models import Article, Comment
from .forms import A_Form, C_Form

# Create your views here.


def index(request):
    articles = Article.objects.all()
    comment_list = []
    for art in articles:
        comment_list.append(art.comment_set.all())

    article_info = zip(articles, comment_list)
    context = {"articles": article_info}

    return render(request, "articles/index.html", context)


def create(request):
    if request.method == "POST":
        form = A_Form(request.POST)
        if form.is_valid():
            form.save()
            return redirect("articles:index")
    else:
        form = A_Form()
    context = {
        "form": form,
    }
    return render(request, "articles/create.html", context)


def update(request, pk):
    a = Article.objects.get(pk=pk)
    if request.method == "POST":
        form = A_Form(request.POST, instance=a)
        if form.is_valid():
            form.save()
            return redirect("articles:index")
    else:
        form = A_Form(instance=a)
    context = {"form": form}
    return render(request, "articles/create.html", context)


def delete(reuqest, pk):
    Article.objects.get(pk=pk).delete()

    return redirect("articles:index")


def detail(request, pk):
    detail_data = Article.objects.get(pk=pk)
    comment = detail_data.comment_set.all()
    if request.method == "POST":
        form = C_Form(request.POST)
        if form.is_valid():
            a = form.save(commit=False)
            a.article = detail_data
            a.save()
        return redirect("articles:detail", detail_data.pk)
    else:
        form = C_Form()
    context = {
        "detail_data": detail_data,
        "form": form,
        "comment": comment,
    }

    return render(request, "articles/detail.html", context)


def delete_comment(request, pk):
    Comment.objects.get(pk=pk).delete()
    return redirect("articles:index")
